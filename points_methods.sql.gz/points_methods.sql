# ************************************************************
# Sequel Pro SQL dump
# Version 4499
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.5.42)
# Database: quranzulfiold
# Generation Time: 2015-10-20 02:26:57 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table points_methods
# ------------------------------------------------------------

DROP TABLE IF EXISTS `points_methods`;

CREATE TABLE `points_methods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `memorize_type_id` tinyint(2) NOT NULL COMMENT 'رقم نوع التسميع',
  `student_age` tinyint(2) NOT NULL COMMENT 'عمر الطالب',
  `no_of_letters` smallint(4) NOT NULL COMMENT 'عدد الأحرف المطلوب حفظها',
  `al_naba_end_aya` tinyint(2) NOT NULL COMMENT 'مثال من سورة الحاقة',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `points_methods` WRITE;
/*!40000 ALTER TABLE `points_methods` DISABLE KEYS */;

INSERT INTO `points_methods` (`id`, `memorize_type_id`, `student_age`, `no_of_letters`, `al_naba_end_aya`)
VALUES
	(1,1,5,40,0),
	(2,1,6,80,0),
	(3,1,7,120,0),
	(4,1,8,160,0),
	(5,1,9,200,0),
	(6,1,10,240,0),
	(7,1,11,280,0),
	(8,1,12,320,0),
	(9,1,13,360,0),
	(10,1,14,400,0),
	(11,1,15,440,0),
	(12,1,16,480,0),
	(13,1,17,520,0),
	(15,2,5,80,0),
	(16,2,6,160,0),
	(17,2,7,240,0),
	(18,2,8,320,0),
	(19,2,9,400,0),
	(20,2,10,480,0),
	(21,2,11,560,0),
	(22,2,12,640,0),
	(23,2,13,720,0),
	(24,2,14,800,0),
	(25,2,15,880,0),
	(26,2,16,960,0),
	(27,2,17,1040,0),
	(28,3,5,200,0),
	(29,3,6,400,0),
	(30,3,7,600,0),
	(31,3,8,800,0),
	(32,3,9,1000,0),
	(33,3,10,1200,0),
	(34,3,11,1400,0),
	(35,3,12,1600,0),
	(36,3,13,1800,0),
	(37,3,14,2000,0),
	(38,3,15,2200,0),
	(39,3,16,2400,0),
	(40,3,17,2600,0);

/*!40000 ALTER TABLE `points_methods` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
